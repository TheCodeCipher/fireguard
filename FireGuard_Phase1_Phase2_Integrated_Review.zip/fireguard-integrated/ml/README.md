# FireGuard ML package

This is the canonical Python package location: `ml/src/fireguard_ml`. Role 2's model, data contracts, loss, and tests live here; do not maintain a second package under a standalone starter.

## Install and run tests (Python 3.11)

From this `ml/` directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m ruff check src tests
python -m pytest tests src/fireguard_ml/tests -v
```

Role 2, Role 3, and Role 4 unit tests are collected from both `tests/` and `src/fireguard_ml/tests/`. The tested package environment is pinned in `pyproject.toml`. The project's configuration is `../configs/unet.yaml` and is loaded by both runners; its SHA-256 is emitted in run reports.

## Synthetic scaffold check

```powershell
python -m fireguard_ml.training.smoke_run --steps 2 --height 304 --width 247 --channels 40
```

This uses synthetic values and is never a WSTS performance result.

## Real sample one-step compute/interface probe

The Role 1 WSTS export can be run through a short compute probe (one warm-up plus five measured optimizer steps by default) using:

```powershell
python -m fireguard_ml.training.real_sample_benchmark "C:\path\to\wsts_fire_21458798_sample_2018-01-06_to_2018-01-07.npz.zip" --input-valid-mask "C:\path\to\input_valid.npy" --target-valid-mask "C:\path\to\target_valid.npy" --report "../docs/phase1/role2_real_sample_benchmark.json"
```

The sample export supplied for the current review does not include those source-aware masks. A provisional plumbing-only run requires the explicit `--allow-provisional-finite-mask` flag. Such a run does not authorize real-data training or count as final mask/compute acceptance evidence. The exported 288x224 example is center-cropped according to the supplied reproduction notes; it cannot restore the original 304x247 border.

## Fail-closed training contract

- Real data adaptation requires separate source-derived input and target validity masks unless the caller explicitly marks a debug/provisional run.
- Target validity masks exclude finite nodata sentinels; zero-valued observations remain valid when the source mask says they are valid.
- The masked loss selects valid values before BCE/Dice arithmetic, rejects non-finite valid values and non-binary valid targets, and cannot be poisoned by masked NaN/Inf values.
- `require_training_handoffs()` blocks official training without Role 1 authoritative masks, Role 4 strict channel approval + ordered channel hash, and Role 4 split path/hash verification.
- No M1 training campaign or scale-up has been started. Global Gate 1 remains with the team lead.



## Phase 2 interfaces integrated for review

Role 3 M3/M4 temporal model interfaces and Role 4 event-level metrics, baselines, split validation and manifests are present in this package. They are code/interface preparation only. `configs/temporal_unet.yaml` keeps training disabled. Official M1 training remains blocked until Global Gate 1 and the source-mask/full-frame/channel agreements are recorded.

`fireguard_ml.data.temporal_adapter.adapt_temporal_sample()` provides the Role 2 full-frame adapter for already-selected `[B,T,C,H,W]` inputs. It applies the shared bottom/right pad to inputs, targets, and masks, and excludes a loss pixel unless the target and every input frame are source-valid there. It does not select channels or run the Role 1 loader.
