"""Documented WSTS processed channel names and replaceable channel selection.

The named 40-channel schema is exploratory. It is not approval for strict M1.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

import torch

PROCESSED_WSTS_CHANNELS: tuple[str, ...] = (
    "viirs_m11", "viirs_i2", "viirs_i1", "ndvi", "evi2",
    "total_precipitation", "wind_speed", "wind_direction", "minimum_temperature",
    "maximum_temperature", "energy_release_component", "specific_humidity",
    "slope", "aspect", "elevation", "pdsi",
    "landcover_evergreen_needleleaf", "landcover_evergreen_broadleaf",
    "landcover_deciduous_needleleaf", "landcover_deciduous_broadleaf",
    "landcover_mixed_forest", "landcover_closed_shrubland", "landcover_open_shrubland",
    "landcover_woody_savanna", "landcover_savanna", "landcover_grassland",
    "landcover_permanent_wetland", "landcover_cropland", "landcover_urban",
    "landcover_cropland_natural_vegetation_mosaic", "landcover_snow_ice",
    "landcover_barren", "landcover_water",
    "forecast_total_precipitation", "forecast_wind_speed", "forecast_wind_direction",
    "forecast_temperature", "forecast_specific_humidity",
    "active_fire_detection_time", "active_fire_binary",
)


@dataclass(frozen=True)
class ChannelSelection:
    names: tuple[str, ...]
    schema_name: str
    selection_status: str
    sha256: str


def channel_names_sha256(names: tuple[str, ...]) -> str:
    payload = json.dumps(list(names), separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def select_channels(
    x: torch.Tensor,
    *,
    names: tuple[str, ...] = PROCESSED_WSTS_CHANNELS,
    selected_names: tuple[str, ...] | None = None,
    strict_approved: bool = False,
    approval_reference: str | None = None,
) -> tuple[torch.Tensor, ChannelSelection]:
    """Select/reorder channels. Strict mode requires named approval evidence."""
    if x.ndim != 4:
        raise ValueError(f"Expected [B,C,H,W], got {tuple(x.shape)}")
    if x.shape[1] != len(names):
        raise ValueError(f"Tensor has {x.shape[1]} channels but schema has {len(names)}")
    selected = names if selected_names is None else selected_names
    if not selected:
        raise ValueError("At least one channel must be selected")
    if len(set(selected)) != len(selected):
        raise ValueError("selected_names contains duplicates")
    unknown = [name for name in selected if name not in names]
    if unknown:
        raise ValueError(f"Unknown channel names: {unknown}")
    if strict_approved and (not approval_reference or selected == names):
        raise ValueError("Strict channel selection requires an explicit reviewed subset and approval reference")
    status = "ROLE4_APPROVED" if strict_approved else "EXPLORATORY_NOT_STRICT_APPROVED"
    indices = torch.tensor([names.index(name) for name in selected], device=x.device)
    return x.index_select(1, indices), ChannelSelection(
        tuple(selected), "wsts_processed_v1", status, channel_names_sha256(tuple(selected))
    )
