# FireGuard integrated role review copy

This folder combines the Role 2 implementation with the supplied Role 3 and Role 4 ML work and the Phase 2 backend included in Role 4's combined snapshot. It is a local integration review copy; it is not a Git checkout, branch, merge, or approval record.

Start with `docs/phase1_phase2_integration_status.md` for the current blockers and acceptance results. The Phase 1 Role 2 handoff is summarized in `docs/phase1/role2_completion_status.md`.

## Local verification

Python 3.11:

```powershell
python -m pip install -e "ml[dev]"
python -m ruff check ml/src ml/tests
python -m pytest ml/tests ml/src/fireguard_ml/tests -q
python -m pip install -e "backend[dev]"
python -m ruff check backend/src backend/tests
python -m pytest backend/tests -q
```

The Role 4 footprint and baseline scripts additionally need the `scripts` ML extra and the extracted WSTS directory. Raw WSTS data is not included here.

`configs/temporal_unet.yaml` leaves temporal training disabled. `configs/unet.yaml` leaves strict M1 approval off. Do not treat the included Role 4 report as a new M1 result or start official M1 training until the lead records Global Gate 1 approval.
